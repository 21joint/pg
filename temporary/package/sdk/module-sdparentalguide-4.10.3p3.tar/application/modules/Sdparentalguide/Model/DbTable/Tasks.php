<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Sdparentalguide
 * @author     Stars Developer
 */

class Sdparentalguide_Model_DbTable_Tasks extends Engine_Db_Table
{
    protected $_rowClass = "Sdparentalguide_Model_Task";
    protected $_name = 'gg_tasks';
} 




