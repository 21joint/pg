<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Sdparentalguide
 * @author     Stars Developer
 */

class Sdparentalguide_Model_SearchTerm extends Core_Model_Item_Abstract
{
  protected $_searchTriggers = false;
} 




