<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Sdparentalguide
 * @author     Stars Developer
 */

class Sdparentalguide_Model_DbTable_Preferences extends Engine_Db_Table
{
    protected $_rowClass = "Sdparentalguide_Model_Preference";
    protected $_name = 'gg_user_preferences';
} 




